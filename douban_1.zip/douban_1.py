#!/usr/bin/env python 
# -*- coding:utf-8 -*-
import requests
from bs4 import BeautifulSoup
import re
import xlwt

class DoubanTag(object):
    def __init__(self):
        self.url = 'https://book.douban.com/tag/?view=type&icn=index-sorttags-all'

    def delchongfu(self,isISBN):

        lens = len(isISBN)
        for i in range(0,lens-1):
            if isISBN[i] == isISBN[lens-1]:
                return None
            elif i != lens-2:
                continue
            else:
                return isISBN[lens-1]


    def getbooktagurl(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_12)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.80 Safari/537.36'
        }
        # url = 'https://book.douban.com/tag/?view=type&icn=index-sorttags-all'
        doubantaghtml = requests.get(self.url,headers = headers)
        doubantaghtml.encoding = "utf-8"
        tagdouban = BeautifulSoup(doubantaghtml.content,'lxml')
        # print(tagdouban)
        div_article = tagdouban.find_all('div',class_="article")
        # print(div_article)
        tagurls = re.findall(r'<a href="/tag/(.*?)">',str(div_article))
        # print(tagurls)
        return tagurls

    def getshulei(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_12)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.80 Safari/537.36'
        }
        doubantaghtml = requests.get(self.url, headers=headers)
        doubantaghtml.encoding = "utf-8"
        tagdouban = BeautifulSoup(doubantaghtml.content, 'lxml')
        # print(tagdouban)
        div_article = tagdouban.find_all('div', class_="article")

        shulei = re.findall(r'<a class="tag-title-wrapper" name="(.*?)">', str(div_article))
        # print(div_article)
        # print(shulei)
        return shulei

    def inputlxs(self,biaoqians,allbookdata):
        book = xlwt.Workbook(encoding='utf-8')
        head = ['序号','书型',  "链接", "书名", "作者", '豆瓣评分', "力荐度", "参与评分人数", "短评数", "书评数", "读书笔记数", "读者数", "出版社", "出版年", "定价",
                "ISBN"]  # 表头
        # for a1 in range(0, len(biaoqians)):
        #         #     sheet = book.add_sheet('豆瓣图书-' + str(biaoqians[a1]) + '', cell_overwrite_ok=True)
        sheet  = book.add_sheet('文学',cell_overwrite_ok=True)
        temp = 0
        for h in range(0, len(head)):
            sheet.write(0, h, head[h])  # 写入表头
        r = 1
        for list in allbookdata:
            temp = temp +1
            l = 1
            # 表中一本书的信息填入
            for data in list:
                sheet.write(r,0,temp)
                sheet.write(r, l, data)
                l += 1
            r += 1
        #     if r == len(allbookdata) - 1:
        #         xls = True
        #         break
        # # if a1 == len(biaoqians) - 1:
        #     break
        return book


# jk = DoubanTag()
# jk.getbooktagurl()
# jk.getshulei()
